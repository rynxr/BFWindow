#!/bin/sh
crc ../adpcm/data/large.pcm > output_large.txt
