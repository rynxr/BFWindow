/* This file gets the file size in bytes
 * Return value is in hex format without '0x'/'0X' prefix
 * jlrao <ary.xsnow@gmail.com>
 * Fri Jun  5 06:23:52 PDT 2015
*/

#include <stdio.h>

int main(int argc, char **argv)
{
	FILE *fid;
	int hex_bytes = 0;

	if (!(fid = fopen(argv[1], "r")))
	{
		printf("ERROR: open %s fail!\n", argv[0]);
	}

	fseek(fid, 0, SEEK_END);
	hex_bytes = ftell(fid);
	fseek(fid, 0, SEEK_SET);
	fclose(fid);

	printf("%x\n", hex_bytes);

	return 0;
}
