#!/bin/sh
search_large > output_large.txt
